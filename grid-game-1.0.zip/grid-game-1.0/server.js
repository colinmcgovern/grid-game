var app = require('express')();
var express = require('express'); 
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = process.env.PORT || 3000;

var GRID_SIZE = 32; 

//Creating the Grid Array 
var grid = new Array(GRID_SIZE);

for (var i = 0; i < GRID_SIZE; i++) {
	grid[i] = new Array(GRID_SIZE);
}

for(var i = 0; i < GRID_SIZE; i++){
	for(var j = 0; j < GRID_SIZE; j++){
		grid[i][j] = 0;
	}
}


app.use("/", express.static(__dirname + '/'));

app.get('/', function(req, res){
  res.sendFile(__dirname + '/');
});

io.on('connection', function(socket){
	
	io.emit('GRID_SIZE', GRID_SIZE);

	socket.on('disconnect', function() {
		console.log("user disconnected");
	});

	socket.on('fill_square', function(msg){
		
		console.log(msg[0] + " " + msg[1]);
		
		grid[msg[0]][msg[1]] = 1;
		
		io.emit('grid', grid);
		
	});
});

http.listen(port, function(){
  console.log('listening on *:' + port);
});
var GRID_SIZE = -1; 

var socket = io();

var canvas = document.getElementById('myCanvas');
var width = canvas.width;
var height = canvas.height;

var c=document.getElementById("myCanvas");
var ctx=c.getContext("2d");

socket.on('GRID_SIZE', function (data) {
        GRID_SIZE = data; 

        for(var i = 0; i < GRID_SIZE; i++){
            ctx.beginPath();
            ctx.moveTo(i*(width/GRID_SIZE),0);
            ctx.lineTo(i*(width/GRID_SIZE),height);
            ctx.stroke();
        }
        
        for(var i = 0; i < GRID_SIZE; i++){
            ctx.beginPath();
            ctx.moveTo(0,i*(height/GRID_SIZE));
            ctx.lineTo(width,i*(height/GRID_SIZE));
            ctx.stroke();
        }
        
        function getMousePos(canvas, evt) {
            var rect = canvas.getBoundingClientRect();
            return {
                x: evt.clientX - rect.left,
                y: evt.clientY - rect.top
            };
        }

        canvas.addEventListener('click', function(evt) {
            
            var pos = getMousePos(canvas, evt);
            socket.emit('fill_square',[Math.floor(pos.x/(width/GRID_SIZE)),Math.floor(pos.y/(height/GRID_SIZE))]);

        } , false);
        
        socket.on('grid', function (data) {
  
            for(var i = 0; i < GRID_SIZE; i++){
                for(var j = 0; j < GRID_SIZE; j++){
                    
                    if(data[i][j]){
                        ctx.beginPath();
                        ctx.fillRect(
                        i * (width/GRID_SIZE),
                        j * (height/GRID_SIZE),
                        (width/GRID_SIZE),
                        (height/GRID_SIZE));
                        ctx.stroke(); 
                    }
                    
                }
            }
 
        });

    
        
});


    

